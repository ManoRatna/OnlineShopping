package com.niit.dao;


import com.niit.model.User;



public interface UserDAO {
	 void registerUser(User user);
	 boolean isEmailValid(String email);
	 public boolean isUsernameValid(String username);
	 public User getUser(String username);
	
}
