package com.niit.dao;

import java.util.List;

import com.niit.model.Admin;
import com.niit.model.Product;

public interface AdminDAO {
	public void Print();
	public boolean addAdmin(Admin admin);
	public boolean deleteAdmin(Admin admin);
	public boolean updateAdmin(Admin admin);
	public Product getProduct(int adminId);
	public List<Product> listProducts();

}
