package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.User;

import com.niit.dao.UserDAO;

@Controller
public class UserController {
	@Autowired
	private UserDAO userDAO;
	@RequestMapping(value="/all/registrationform") 	
	public ModelAndView  getRegistrationForm(){
		return new ModelAndView("Register","user",new User());
	}
	@RequestMapping(value="/all/registercustomer")
	public String registerUser(@ModelAttribute User user,BindingResult result,Model model){
		if(result.hasErrors())
			return "Register";
		if(!userDAO.isUsernameValid(user.getUsername())){
			model.addAttribute("duplicateUsername","Username already exists.. please enter different username");
			return "Register";
		}
		if(!userDAO.isEmailValid(user.getEmail())){
			model.addAttribute("duplicateEmail","Email Id already exists.. Please enter different email address");
			return "Register";
		}
		
		userDAO.registerUser(user);
		return "Login";
	}
}
