package com.niit.ProjectBackend;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.config.ApplicationConfig;
import com.niit.dao.AdminDAO;
import com.niit.model.Admin;


public class AdminUnitTest {

	static AdminDAO adminDAO;

	@BeforeClass
	public static void executeFirst()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		adminDAO=(AdminDAO)context.getBean("adminDAO");
	}
	
	@Test
	public void addAdminTest()
	{
		Admin admin=new Admin();
		admin.setCategoryId(2);
		admin.setAdminName("camera");
		admin.setAdminId(1);
		admin.setSupplierId(76);
		admin.setProductId(2);
		assertTrue("Problem in Category Insertion",adminDAO.addAdmin(admin));
	}

}
