package com.niit.dao;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.model.Cart;
import com.niit.model.CartItem;
import com.niit.model.Order;
import com.niit.model.User;



public class CartDAOImpl implements CartDAO {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public Cart getCart(int cartId) {
		Session session=sessionFactory.getCurrentSession();
		Cart cart=(Cart)session.get(Cart.class, cartId);
		//select records both from parent and child table , fetchType.EAGER
		return cart;
	}

	@Override
	public Order CreateOrder(Cart cart) {
		Session session=sessionFactory.getCurrentSession();
		Order order=new Order();
		order.setPurchaseDate(new Date());
		List<CartItem> cartItems=cart.getCartItems();
		double grandTotal=0;
		for(CartItem cartItem:cartItems){
			grandTotal=cartItem.getSubtotal() + grandTotal;
		}
		
		cart.setGrandTotal(grandTotal);//update grandtotal column in cart
		order.setCart(cart);//FK cart_id
		User user=cart.getUser();
		order.setUser(user);//FK customer_id
		session.save(order);
		//insert into customerorder ..
		//update cart set grandtotal where id=?
		//update shippingaddress set ..... where id=?
		return order;
	}
	



	@Transactional
	public void addorUpdateCartitem(CartItem cartItem) {
		Session session=sessionFactory.getCurrentSession();
		session.update(cartItem);
	}



	@Transactional
	public void deleteCartitem(int cartItemId) {
		Session session=sessionFactory.getCurrentSession();
	    //select * from cartitem where id=?
	    CartItem cartItem=(CartItem)session.get(CartItem.class, cartItemId);
	    //delete from cartitem where id=?
	    session.delete(cartItem);
		
		
	}
			
		

	

}
