package com.niit.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;


import com.niit.model.Product;
import com.niit.model.User;

import com.niit.model.Authority;


@Repository(value="userDAO")
@Transactional
@Component
@EnableTransactionManagement
public class UserDAOImpl implements UserDAO{

	@Autowired
	SessionFactory sessionFactory;

	
	@Override
	public boolean isEmailValid(String email) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from User where email=?");
		query.setString(0, email);	
		User user=(User)query.uniqueResult();
		if(user!=null)
			return false;
		else
			return true;
		
	}

	@Override
	public boolean isUsernameValid(String username) {
		Session session=sessionFactory.getCurrentSession();
		User user=(User)session.get(User.class, username);
		if(user!=null)
			return false; 
		else
			return true;
	}

	@Override
	public User getUser(String username) {
		Session session=sessionFactory.getCurrentSession();
		User user=(User)session.get(User.class,username);
		return user;
	}

	@Override
	public void registerUser(User user) {
Session session=sessionFactory.getCurrentSession();
		
		Authority authority=new Authority();
		authority.setRole("ROLE_USER");
		authority.setUser(user);
		//user.getUsername().setAuthority(authority);
		//user.getUsername().setEnabled(true);
		
		session.save(user);
		
	}
	
		

	

}
