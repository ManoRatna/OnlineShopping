package com.niit.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.model.Admin;
import com.niit.model.Product;
import com.niit.model.Supplier;

@Repository(value="adminDAO")
@Transactional
@Component
@EnableTransactionManagement
public class AdminDAOImpl implements AdminDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	public boolean addAdmin(Admin admin) {
		try
		{
		sessionFactory.getCurrentSession().save(admin);
		return true;
		}
		catch(Exception e)
		{
		System.out.println("Exception Arised:"+e);
		return false;
		}
	}
	public void Print(){
		System.out.println("Dao is triggered");
	
	}
	public boolean deleteAdmin(Admin admin) {
		try
		{
			sessionFactory.getCurrentSession().delete(admin);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception Arised:"+e);
			return false;
		}
	}

	public boolean updateAdmin(Admin admin) {
		try
		{
			sessionFactory.getCurrentSession().update(admin);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception Arised:"+e);
			return false;
		}
	}

	

	public List<Product> listProducts() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Admin");
		List<Product> listAdmins=(List<Product>)query.list();
		return listAdmins;
	}
	public Product getProduct(int adminId) {
		// TODO Auto-generated method stub
		return null;
	}

}
