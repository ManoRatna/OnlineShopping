package com.niit.ProjectBackend;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.ProductDAO;
import com.niit.model.Product;

public class ProductUnitTest {

	static ProductDAO productDAO;

	@BeforeClass
	public static void executeFirst()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		productDAO=(ProductDAO)context.getBean("productDAO");
	}
	@Test
	public void addProductTest()
	{
		Product product=new Product();
		product.setProductId(1);
		product.setProductName("agatha christie");
		product.setProdDesc("detective Types");
		product.setCategoryId(1);
		product.setPrice(1200);
		product.setStock(3);
		product.setSupplierId(76);
		
		assertTrue("Problem in Category Insertion",productDAO.addProduct(product));
	}
	
}
