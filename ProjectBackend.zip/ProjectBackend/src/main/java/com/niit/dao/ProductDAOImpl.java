package com.niit.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.model.Category;
import com.niit.model.Product;

public class ProductDAOImpl implements ProductDAO{
	@Autowired
	SessionFactory sessionFactory;
	@Transactional
	public boolean addProduct(Product product) {
		try
		{
		sessionFactory.getCurrentSession().save(product);
		return true;
		}
		catch(Exception e)
		{
		System.out.println("Exception Arised:"+e);
		return false;
		}
	}

	public Product getProduct(int ProductId) {
		Session session=sessionFactory.openSession();
		Product product=(Product)session.get(Product.class,ProductId);
		return product;
	}
	@Transactional
	@Override
	public boolean deleteProduct(Product product) {
		try
		{
			sessionFactory.getCurrentSession().delete(product);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception Arised:"+e);
			return false;
		}
		
	}
	@Transactional
	@Override
	public boolean updateProduct(Product product) {
		try
		{
			sessionFactory.getCurrentSession().update(product);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception Arised:"+e);
			return false;
		}
	
	}
@Override
	public List<Product> getProducts() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Product");
		List<Product> listProducts=(List<Product>)query.list();
		return listProducts;
	}

	@Override
	public List<Product> getCatId(int CategoryId) {
		Session session=sessionFactory.getCurrentSession();//hql
		
		return session.createQuery("from Product p where p.category.categoryId="+":cateId ").setInteger("cateId", CategoryId).list() ;
	}
	
}
