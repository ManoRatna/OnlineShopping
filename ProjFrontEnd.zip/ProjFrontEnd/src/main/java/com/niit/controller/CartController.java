package com.niit.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.dao.CartDAO;
import com.niit.dao.ProductDAO;
import com.niit.dao.UserDAO;
import com.niit.model.Cart;
import com.niit.model.CartItem;

import com.niit.model.Order;
import com.niit.model.Product;
import com.niit.model.User;

@Controller
public class CartController {

	@Autowired
	CartDAO cartDAO;
	
	@Autowired
	ProductDAO productDAO;
	
	@Autowired
	UserDAO userDAO;

	
	@RequestMapping(value="/cart/addtocart/{id}")
	public String addToCart(@AuthenticationPrincipal Principal principal,@PathVariable int id){
		Product product=productDAO.getProduct(id);
		String username=principal.getName();
		User user=userDAO.getUser(username);
		
		Cart cart=user.getCart();
		
		List<CartItem> cartItems=cart.getCartItems();
		
		for(CartItem cartItem:cartItems){
			if(cartItem.getProduct().getProductId()==id){
				//cartItem.setQuantity(quantity); //update the quantity
				cartItem.setSubtotal(product.getPrice()); //update the totalprice
				cartDAO.addorUpdateCartitem(cartItem); //update cartitem , quantity and totalprice 
				return "redirect:/cart/getcart";
			}
		}
		
		
		CartItem cartItem=new CartItem();
	//	cartItem.setQuantity(quantity);
		cartItem.setSubtotal( product.getPrice());
		cartItem.setCart(cart);
		cartItem.setProduct(product);
		cartDAO.addorUpdateCartitem(cartItem);//insert cartitem.
		return "redirect:/cart/getcart";
		
	}
   
	@RequestMapping(value="/cart/getcart")
	public String getCart(@AuthenticationPrincipal Principal principal,Model model){
		String username=principal.getName();
		User user=userDAO.getUser(username);
		
		Cart cart=user.getCart();
		model.addAttribute("cart",cart);
		return "cart";
	}
	
	@RequestMapping(value="/cart/checkout/{cartId}")
	public String checkout(@PathVariable int cartId,Model model){
		Cart cart=cartDAO.getCart(cartId);
		List<CartItem> cartItems=cart.getCartItems();
		
		User user=cart.getUser();
		
		model.addAttribute("cartId",cartId);
		if(cartItems.size()>0) {
		return "shippingAddressForm";
		}else {
			return"redirect:/cart/getcart" ;
			
		}
	}
	
	
	@RequestMapping(value="/cart/createorder/{cartId}")
	//from shippingaddressform.jsp to createOrder method
	public String createOrder(@PathVariable int cartId,BindingResult result,Model model){
		//set the updated shippingaddress for the customer
		//get customer object
		//using cartid , get cart, from cart , get customer,
		//Update shipping address for the customer
		//if(result.hasErrors())
			//return "ShippingAddress";
		Cart cart=cartDAO.getCart(cartId);
		User user=cart.getUser();
		//update shippingaddress set.... where customerid=?
		cart.setUser(user);
		Order order=cartDAO.CreateOrder(cart);//insert into customerorder
		model.addAttribute("order",order);
		model.addAttribute("cartId",cartId);
		return "Order";
	}
	
	@RequestMapping(value="/cart/confirm/{cartId}")
	public String confirm(@PathVariable int cartId){
		Cart cart=cartDAO.getCart(cartId);
	
		Product product=new Product();
				List<CartItem> cartItems=cart.getCartItems();
		
		for(CartItem cartItem : cartItems){//for(T v:collection)
			
			cartDAO.deleteCartitem(cartItem.getId());//delete from cartitem where id=3
			productDAO.getProduct(cartItem.getId());
		}
		return "ThankYou";
	}
	
}

		



