package com.niit.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.niit.model.CartItem;
import com.niit.model.User;


@Entity
public class Cart {
	@Id
	@GeneratedValue
private int id;
private double grandTotal;
@OneToOne
private User user;
@OneToMany(mappedBy="cart",fetch=FetchType.EAGER)
private List<CartItem> cartItems;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getGrandTotal() {
	return grandTotal;
}
public void setGrandTotal(double grandTotal) {
	this.grandTotal = grandTotal;
}

public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public List<CartItem> getCartItems() {
	return cartItems;
}
public void setCartItems(List<CartItem> cartItems) {
	this.cartItems = cartItems;
}


}
