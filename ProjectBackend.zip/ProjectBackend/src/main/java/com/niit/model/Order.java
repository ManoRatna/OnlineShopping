package com.niit.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;






@Entity
public class Order {
	@Id
	@GeneratedValue
private int orderId;
private Date purchaseDate;
@ManyToOne(cascade=CascadeType.ALL)
private Cart cart;
@ManyToOne(cascade=CascadeType.ALL)
private User user;




public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public Date getPurchaseDate() {
	return purchaseDate;
}
public void setPurchaseDate(Date purchaseDate) {
	this.purchaseDate = purchaseDate;
}


public Cart getCart() {
	return cart;
}
public void setCart(Cart cart) {
	this.cart = cart;
}


}
