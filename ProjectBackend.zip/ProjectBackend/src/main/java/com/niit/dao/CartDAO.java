package com.niit.dao;

import java.util.List;

import com.niit.model.Cart;
import com.niit.model.CartItem;
import com.niit.model.Order;


public interface CartDAO {

	public void addorUpdateCartitem(CartItem cartItem);
	
	public void deleteCartitem(int cartItemId);
	
	public Cart getCart(int cartId);
	public Order CreateOrder(Cart cart);
	
}
